#!/usr/bin/env python3
"""
Smart Portfolio Allocation

Allocates capital across Large/Mid/Micro caps:
- Target: 60% Large / 20% Mid / 20% Micro
- Fallback: If insufficient microcaps, allocate to mid/large
- Ensures 100% capital deployment
"""

def calculate_smart_allocation(
    candidates,  # Dict: {'large_caps': [...], 'mid_caps': [...], 'micro_caps': [...]}
    total_capital,
    max_positions=7,
    target_allocation={'large': 0.60, 'mid': 0.20, 'micro': 0.20}
):
    """
    Calculate smart allocation across market caps.

    Args:
        candidates: Dict of scored candidates by category
        total_capital: Total capital to deploy
        max_positions: Maximum number of positions
        target_allocation: Target % for each category

    Returns:
        allocation_plan: Dict with positions per category and capital per position
    """

    # Count available candidates
    available = {
        'large': len(candidates.get('large_caps', [])),
        'mid': len(candidates.get('mid_caps', [])),
        'micro': len(candidates.get('micro_caps', []))
    }

    print()
    print("=" * 80)
    print("SMART ALLOCATION CALCULATOR")
    print("=" * 80)
    print(f"Total Capital: ₹{total_capital:,.0f}")
    print(f"Max Positions: {max_positions}")
    print()

    print("Available Candidates:")
    print(f"  Large-caps: {available['large']}")
    print(f"  Mid-caps:   {available['mid']}")
    print(f"  Micro-caps: {available['micro']}")
    print()

    # Calculate target positions per category
    target_positions = {
        'large': int(max_positions * target_allocation['large']),
        'mid': int(max_positions * target_allocation['mid']),
        'micro': int(max_positions * target_allocation['micro'])
    }

    # Adjust for rounding (ensure sum = max_positions)
    total_target = sum(target_positions.values())
    if total_target < max_positions:
        # Add remaining to large caps
        target_positions['large'] += (max_positions - total_target)

    print("Target Positions (60/20/20):")
    print(f"  Large-caps: {target_positions['large']} positions")
    print(f"  Mid-caps:   {target_positions['mid']} positions")
    print(f"  Micro-caps: {target_positions['micro']} positions")
    print()

    # FALLBACK LOGIC: Adjust if insufficient candidates
    actual_positions = {}
    redistributed = {}

    for category in ['large', 'mid', 'micro']:
        actual = min(target_positions[category], available[category])
        actual_positions[category] = actual
        shortfall = target_positions[category] - actual
        redistributed[category] = shortfall

    print("Actual Positions (after availability check):")
    print(f"  Large-caps: {actual_positions['large']} positions")
    print(f"  Mid-caps:   {actual_positions['mid']} positions")
    print(f"  Micro-caps: {actual_positions['micro']} positions")

    # Redistribute shortfall
    total_shortfall = sum(redistributed.values())
    if total_shortfall > 0:
        print()
        print(f"⚠️  Shortfall: {total_shortfall} positions")
        print("   Redistributing to available categories...")

        # Redistribute to categories with room
        # Priority: mid -> large (avoid putting all in large)
        for recipient in ['mid', 'large']:
            if total_shortfall == 0:
                break

            room = available[recipient] - actual_positions[recipient]
            can_add = min(room, total_shortfall)

            if can_add > 0:
                actual_positions[recipient] += can_add
                total_shortfall -= can_add
                print(f"   +{can_add} to {recipient}")

    print()
    print("Final Allocation:")
    print(f"  Large-caps: {actual_positions['large']} positions")
    print(f"  Mid-caps:   {actual_positions['mid']} positions")
    print(f"  Micro-caps: {actual_positions['micro']} positions")
    print()

    # Calculate capital per category
    capital_allocation = {
        'large': total_capital * target_allocation['large'],
        'mid': total_capital * target_allocation['mid'],
        'micro': total_capital * target_allocation['micro']
    }

    # Adjust capital if positions were redistributed
    if redistributed['micro'] > 0:
        # Micro couldn't fill its quota, redistribute capital
        micro_shortfall_pct = redistributed['micro'] / max_positions
        extra_capital = total_capital * micro_shortfall_pct * target_allocation['micro']

        # Give to mid first
        if actual_positions['mid'] > target_positions['mid']:
            mid_extra = extra_capital * 0.5
            large_extra = extra_capital * 0.5
        else:
            mid_extra = 0
            large_extra = extra_capital

        capital_allocation['mid'] += mid_extra
        capital_allocation['large'] += large_extra
        capital_allocation['micro'] -= extra_capital

    # Calculate capital per position
    capital_per_position = {}
    for category in ['large', 'mid', 'micro']:
        if actual_positions[category] > 0:
            capital_per_position[category] = capital_allocation[category] / actual_positions[category]
        else:
            capital_per_position[category] = 0

    print("Capital Allocation:")
    print(f"  Large-caps: ₹{capital_allocation['large']:,.0f} (₹{capital_per_position['large']:,.0f}/position)")
    print(f"  Mid-caps:   ₹{capital_allocation['mid']:,.0f} (₹{capital_per_position['mid']:,.0f}/position)")
    print(f"  Micro-caps: ₹{capital_allocation['micro']:,.0f} (₹{capital_per_position['micro']:,.0f}/position)")
    print()

    total_allocated = sum(capital_allocation.values())
    print(f"Total Allocated: ₹{total_allocated:,.0f} ({total_allocated/total_capital*100:.1f}%)")
    print("=" * 80)

    return {
        'positions': actual_positions,
        'capital': capital_allocation,
        'capital_per_position': capital_per_position,
        'total_positions': sum(actual_positions.values())
    }


def select_positions(candidates, allocation_plan):
    """
    Select actual positions based on allocation plan.

    Args:
        candidates: Dict of lists, each item has 'ticker' and 'score'
        allocation_plan: Output from calculate_smart_allocation()

    Returns:
        selected: List of selected positions with allocation
    """
    selected = []

    for category in ['large_caps', 'mid_caps', 'micro_caps']:
        category_short = category.split('_')[0]  # 'large', 'mid', 'micro'

        num_positions = allocation_plan['positions'][category_short]
        capital_per_pos = allocation_plan['capital_per_position'][category_short]

        if num_positions == 0:
            continue

        # Get top N candidates by score
        category_candidates = candidates.get(category, [])

        # Sort by score descending
        sorted_candidates = sorted(category_candidates, key=lambda x: x.get('score', 0), reverse=True)

        # Take top N
        for candidate in sorted_candidates[:num_positions]:
            selected.append({
                'ticker': candidate['ticker'],
                'category': category_short.capitalize() + '-cap',
                'score': candidate.get('score', 0),
                'allocated_capital': capital_per_pos
            })

    return selected


if __name__ == "__main__":
    # Test the allocation logic
    test_candidates = {
        'large_caps': [{'ticker': f'LARGE{i}.NS', 'score': 70+i} for i in range(10)],
        'mid_caps': [{'ticker': f'MID{i}.NS', 'score': 65+i} for i in range(5)],
        'micro_caps': [{'ticker': f'MICRO{i}.NS', 'score': 60+i} for i in range(2)]  # Only 2 microcaps
    }

    plan = calculate_smart_allocation(
        test_candidates,
        total_capital=1000000,
        max_positions=7
    )

    print()
    print("=" * 80)
    print("SELECTED POSITIONS")
    print("=" * 80)

    selected = select_positions(test_candidates, plan)

    for pos in selected:
        print(f"{pos['ticker']:15s} | {pos['category']:10s} | Score: {pos['score']:3d} | ₹{pos['allocated_capital']:,.0f}")

    print()
    print(f"Total Positions: {len(selected)}")
    print(f"Total Capital: ₹{sum(p['allocated_capital'] for p in selected):,.0f}")
