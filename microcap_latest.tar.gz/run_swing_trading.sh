#!/bin/bash
# run_swing_trading.sh - Run swing trading at market close (4 PM IST)
# Add to crontab: 0 16 * * 1-5 (4 PM Mon-Fri)

cd /Users/brosshack/project_blank/Microcap-India

echo "=========================================="
echo "Swing Trading - Daily Run"
echo "Time: $(TZ='Asia/Kolkata' date)"
echo "=========================================="

# Run swing trading
/Users/brosshack/project_blank/venv/bin/python3 swing_trading.py

SWING_STATUS=$?

if [ $SWING_STATUS -ne 0 ]; then
    echo "ERROR: Swing trading failed with status $SWING_STATUS"
    exit $SWING_STATUS
fi

echo ""
echo "=========================================="
echo "✅ Swing Trading Complete"
echo "Time: $(TZ='Asia/Kolkata' date)"
echo "=========================================="

exit 0
