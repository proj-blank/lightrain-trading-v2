#!/bin/bash
# run_eod_report.sh - Send end-of-day position report

cd /Users/brosshack/project_blank/Microcap-India

# Activate virtual environment
source /Users/brosshack/project_blank/venv/bin/activate

# Run EOD report
python3 send_eod_report.py
