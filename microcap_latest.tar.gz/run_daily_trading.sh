#!/bin/bash
# Automated daily trading script with dynamic screening
# This script is designed to be run by cron

# Navigate to project directory
cd /Users/brosshack/project_blank/Microcap-India

echo "=========================================="
echo "Daily Trading Workflow Started"
echo "Time: $(date)"
echo "=========================================="

# Step 1: Screen stocks and update watchlist
echo ""
echo "Step 1: Screening stocks..."
/Users/brosshack/project_blank/venv/bin/python3 daily_screening.py
SCREEN_STATUS=$?

if [ $SCREEN_STATUS -ne 0 ]; then
    echo "ERROR: Screening failed with status $SCREEN_STATUS"
    exit $SCREEN_STATUS
fi

echo ""
echo "✅ Screening complete"
echo ""

# Step 2: Run trading on updated watchlist
echo "Step 2: Running trading..."
/Users/brosshack/project_blank/venv/bin/python3 daily_trading.py
TRADE_STATUS=$?

if [ $TRADE_STATUS -ne 0 ]; then
    echo "ERROR: Trading failed with status $TRADE_STATUS"
    exit $TRADE_STATUS
fi

echo ""
echo "=========================================="
echo "✅ Daily Trading Workflow Complete"
echo "Time: $(date)"
echo "=========================================="

exit 0
